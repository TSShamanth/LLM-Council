#include <EloquentTinyML.h> // TinyML library
#include "model.h"          // Model header file generated from .tflite
#include <vector>

// Define model parameters
#define INPUTS 5            // Number of input features
#define OUTPUTS 1           // Number of output classes (binary)
#define TENSOR_ARENA_SIZE 2 * 1024 // Adjust if needed for larger models

// Initialize TinyML
Eloquent::TinyML::TensorFlowLite ml;

// Input and output buffers
float input[INPUTS];
float output[OUTPUTS];

void setup() {
    Serial.begin(115200);
    delay(1000);

    // Begin TinyML
    if (!ml.begin(model, TENSOR_ARENA_SIZE)) {
        Serial.println("Failed to initialize model");
        while (true);
    }
    Serial.println("Model initialized successfully");
}

void loop() {
    // Example input (replace with actual data or sensor inputs)
    input[0] = 100.0; // Issue Size (in crores)
    input[1] = 20.0;  // QIB
    input[2] = 15.0;  // HNI
    input[3] = 30.0;  // RII
    input[4] = 1.5;   // Issue

    // Perform inference
    ml.predict(input, output);

    // Print the result
    Serial.print("Probability of positive listing gain: ");
    Serial.println(output[0]);
    
    delay(1000); // Delay for readability
}
