 // import file from drive
import pandas as pd

file_path = '/content/drive/MyDrive/ipo_2010_2021.csv'
df = pd.read_csv(file_path)
print(df.head(5))

// Drop the columns by their names
df = df.drop(columns=['IPO Name'])

from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
df['IPO Name Encoded'] = label_encoder.fit_transform(df['IPO Name'])

//Check for missing values
print(df.isnull().sum())

print(df.columns)

//Display cleaned dataset
df.head()

//Convert columns with potential comma formatting to numeric
for col in ['Issue Size (in crores)', 'QIB', 'HNI', 'RII', 'Total', 'Issue', 'Listing Open', 'Listing Close', 'Listing Gains(%)']:  // Add other relevant columns
    try:
        df[col] = df[col].str.replace(',', ' ').astype(float)
    except AttributeError:
        //Column might already be numeric, skip
        pass


//Assuming 'Issue Price' and 'Listing Price' columns exist in your dataset
//Create the target variable based on gain or loss on the first day

//Calculate gain or loss (1 for gain, 0 for loss)
df['Outcome'] = (df['Listing Open'] > df['Issue']).astype(int)

//Display the new Outcome column to confirm
print(df[['Issue', 'Listing Open', 'Outcome']].head())

#include <pandas> as pd
#include <numpy> as np
from sklearn.model_selection #include <train_test_split>
from sklearn.preprocessing #include <StandardScaler>
#include <tensorflow> as tf
from tensorflow.keras #include <Sequential>
from tensorflow.keras.layers #include <Dense>



//Data preprocessing: convert 'Listing Gains(%)' to a binary classification target
df['Listing_Gains_Positive'] = (df['Listing Gains(%)'] > 0).astype(int)

//Select features (you can modify this based on feature importance)
features = ['Issue Size (in crores)', 'QIB', 'HNI', 'RII', 'Issue']
X = df[features].fillna(0)
y = df['Listing_Gains_Positive']

//Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

//Scale the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

//Build the model
model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')  # Binary classification output
])

//Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

//Train the model
history = model.fit(X_train, y_train, epochs=300, batch_size=32, validation_split=0.2, verbose=2)

//Evaluate the model on the test set
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {accuracy:.2f}")

